import RPi.GPIO as GPIO
from time import sleep
from getObjects import getObjects
from webCam import getImg

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)


class Motor():
    def __init__(self, In1A, In2A, In1B, In2B):
        self.In1A = In1A
        self.In2A = In2A
        self.In1B = In1B
        self.In2B = In2B
        GPIO.setup(self.In1A, GPIO.OUT)
        GPIO.setup(self.In2A, GPIO.OUT)
        GPIO.setup(self.In1B, GPIO.OUT)
        GPIO.setup(self.In2B, GPIO.OUT)
        self.pwmA1 = GPIO.PWM(self.In1A, 1000);
        self.pwmA2 = GPIO.PWM(self.In2A, 1000);
        self.pwmA1.start(0);
        self.pwmA2.start(0);
        self.pwmB1 = GPIO.PWM(self.In1B, 1000);
        self.pwmB2 = GPIO.PWM(self.In2B, 1000);
        self.pwmB1.start(0);
        self.pwmB2.start(0);

    def move(self, speed=0.5, turn=0, t=0):
        #print(turn)
        speed *=100
        turn *= 100
        if speed>0:
           leftSpeed = speed + turn
           rightSpeed = speed - turn
        else:
           leftSpeed = speed - turn
           rightSpeed = speed + turn
        if leftSpeed > 100:
            leftSpeed = 100
        elif leftSpeed < -100:
            leftSpeed = -100
        if rightSpeed > 100:
            rightSpeed = 100
        elif rightSpeed < -100:
            rightSpeed = -100
        print(f'turn: {turn}')
        print(f'left speed: {leftSpeed}, right speed: {rightSpeed}')
        #self.pwmA.ChangeDutyCycle(abs(leftSpeed))
        #self.pwmB.ChangeDutyCycle(abs(rightSpeed))

        if leftSpeed > 0:
            self.pwmA1.ChangeDutyCycle(0)
            self.pwmA2.ChangeDutyCycle(abs(leftSpeed))
        elif leftSpeed==0:
            self.pwmA1.ChangeDutyCycle(0)
            self.pwmA2.ChangeDutyCycle(0)
        else :
            self.pwmA2.ChangeDutyCycle(0)
            self.pwmA1.ChangeDutyCycle(abs(leftSpeed))

        if rightSpeed > 0:
            self.pwmB2.ChangeDutyCycle(0)
            self.pwmB1.ChangeDutyCycle(abs(rightSpeed))
        elif leftSpeed==0:
            self.pwmB1.ChangeDutyCycle(0)
            self.pwmB2.ChangeDutyCycle(0)
        else:
            self.pwmB1.ChangeDutyCycle(0)
            self.pwmB2.ChangeDutyCycle(abs(rightSpeed))
        sleep(t)
    def stopturn(self):
        print('1')
        self.move(0, -0.2, 2.1)
        

    def stop(self, t=0):
        self.pwmA1.start(0);
        self.pwmA2.start(0);
        self.pwmB1.start(0);
        self.pwmB2.start(0);
        sleep(t)


def main():
    #motor.move(0.1, 0, 3)
    #motor.move(0.2, 0.1, 3)
    #motor.stop(2)
    l=0
    while True:
        img = getImg()
        result, objectInfo = getObjects(img, 0.55, 0.2, objects=['stop sign'])
        if objectInfo and l==0:
            motor.stopturn()
            motor.stop(2)
            l=1
        else:
            motor.move(0.3, 0, 0.5)


if __name__ == '__main__':
    motor = Motor(2, 3, 17, 27)
    main()