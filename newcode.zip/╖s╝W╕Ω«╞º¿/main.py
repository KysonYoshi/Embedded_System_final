from motor import Motor
from lanedetect import getLaneCurve
import cv2
from webCam import getImg
from getObjects import getObjects
#import webCam 
##################################################
motor = Motor(2, 3, 17, 27)
##################################################

def main():
 
    img = getImg()
    curveVal= getLaneCurve(img,2)
    print(curveVal)
    sen = 0.00043 # SENSITIVITY
    maxVAl= 0.3 # MAX SPEED
    #if curveVal>maxVAl:curveVal = maxVAl
    #if curveVal<-maxVAl: curveVal =-maxVAl
    #print(curveVal)
    if curveVal>0:
        #sen =0.005#0.43
        if curveVal<5: curveVal=0
    else:
        if curveVal>-5: curveVal=0
    #print(f'curveVal*sen: {curveVal*0.005}')
    #print(f"sen: {sen}")
    motor.move(0.25,curveVal*sen,0.005)
    #cv2.waitKey(1)
"""def main():
    img = getImg()
    result, objectInfo = getObjects(img, 0.55, 0.2, objects=['stop sign'])
    if objectInfo:
        print("stop")
        motor.stop(2)
    else:
        curveVal = getLaneCurve(img, 2)
        sen = 1.3  # SENSITIVITY
        maxVAl = 0.3  # MAX SPEED
        if curveVal > maxVAl: curveVal = maxVAl
        if curveVal < -maxVAl: curveVal = -maxVAl
        # print(curveVal)
        if curveVal > 0:
            sen = 1
            if curveVal < 0.05: curveVal = 0
        else:
            if curveVal > -0.08: curveVal = 0
        #motor.move(0.20, -curveVal * sen, 0.05)
    # cv2.waitKey(1)"""
     
 
if __name__ == '__main__':
    while True:
        main()
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    motor.stop(2)